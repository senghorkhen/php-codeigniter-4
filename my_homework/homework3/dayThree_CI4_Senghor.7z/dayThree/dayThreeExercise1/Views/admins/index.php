<?= $this->extend('layouts/layout') ?>

<?= $this->section('navbar_blog') ?>
<?= $this->include('layouts/navbar') ?>
    <h1 class="text-success">Administrator</h1>
<?= $this->endSection() ?>