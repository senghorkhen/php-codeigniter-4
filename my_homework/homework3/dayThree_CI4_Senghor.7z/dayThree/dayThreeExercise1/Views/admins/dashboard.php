<?= $this->extend('layouts/layout') ?>

<?= $this->section('navbar_blog') ?>
<?= $this->include('layouts/navbar') ?>
    <h1 class="text-danger">Dashboard Administrator</h1>
<?= $this->endSection() ?>