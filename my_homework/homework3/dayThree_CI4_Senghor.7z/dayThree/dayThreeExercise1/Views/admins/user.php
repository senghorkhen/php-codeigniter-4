<?= $this->extend('layouts/layout') ?>

<?= $this->section('navbar_blog') ?>
<?= $this->include('layouts/navbar') ?>
    <h1 class="text-primary">User Administrator</h1>
<?= $this->endSection() ?>