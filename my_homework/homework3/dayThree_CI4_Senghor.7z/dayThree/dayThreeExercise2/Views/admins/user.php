<?= $this->extend('layouts/layout') ?>

<?= $this->section('navbar_blog') ?>
<?= $this->include('layouts/navbar') ?>
    <h1 class="text-primary">User List</h1>
<?= $this->endSection() ?>