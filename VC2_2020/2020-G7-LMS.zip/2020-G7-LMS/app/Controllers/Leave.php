<?php namespace App\Controllers;

class Leave extends BaseController
{
	public function showLeave()
	{
		return view('leaves/leave');
	}

	//--------------------------------------------------------------------

}