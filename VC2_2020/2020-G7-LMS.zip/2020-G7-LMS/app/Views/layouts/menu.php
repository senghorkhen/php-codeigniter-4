
<nav class="navbar navbar-expand-md bg-dark text-white navbar-dark">
    <img class="navbar-brand" src="images/lms_app.png" alt="logo" width= "40">Leave Management System
  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon">
    <img class="rounded mx-auto d-block" src="images/lms_app.png" alt="" width=150px height=150px>
    </span>
  </button>
  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="nav navbar-nav ml-auto">
         <a class="nav-link " href="#">Your leaves</a>
         <a class="nav-link " href="leaves">Leaves</a>
         <a class="nav-link " href="#">Employees</a>
         <a class="nav-link " href="#">Positions</a>
         <a class="nav-link " href="#">Departments</a>
        <li class="dropdown ">
         <a href="#" class="dropdown-toggle text-uppercase text-white nav-link " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" >Ronnan</a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="#">Profile</a>
                <a class="dropdown-item" href="#">Log out</a>
            </div>
        </li>
    </ul>
  </div>
</nav>
