<?= $this->extend('layouts/layout')?>
<?= $this->section('content_blog')?>
    <h1 class="text-warning">Add new teacher</h1>
    <form action="" method="post">
        <div class="form-group">
            <label for="name"></label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
        </div>
        <div class="form-group">
            <label for="email"></label>
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter email">
        </div>
        <div class="form-group">
            <label for="password"></label>
            <input type="text" class="form-control" name="password" id="password" placeholder="Enter password">
        </div>
        <div class="form-group">
            <label for="age"></label>
            <input type="text" class="form-control" name="age" id="age" placeholder="Enter age">
        </div>
        <div class="form-group">
            <label for="province"></label>
            <input type="text" class="form-control" name="province" id="province" placeholder="Enter province">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?= $this->endSection()?>