
<?= $this->extend('layouts/layout')?>
<?= $this->section('content-blog')?>
<?= $this->include('layouts/navbar') ?>
<h1 class="text-success">Administrator</h1>
<br>
<a href="/students/add/" class="btn btn-info">Add Student</a>
<hr>
    <div class="contaienr">
        <table class="table table-bordered">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Age</th>
                <th>Province</th>
                <th>Status</th>
            </tr>
            <?php foreach($userData as $student):?>
                <tr>
                    <td><?= $student['name']?></td>
                    <td><?= $student['email']?></td>
                    <td><?= $student['password']?></td>
                    <td><?= $student['age']?></td>
                    <td><?= $student['province']?></td>
                    <td> 
                        <a href="/students/remove/<?= $student['id'] ?>">
                            <i class="material-icons text-danger" >delete</i>
                        </a> 
                        <a href="/student/remove<?= $student['id'] ?>">
                            <i class="material-icons text-info" >edit</i>
                        </a> 
                    </td>
                </tr>
            <?php endforeach?>
        </table>
    </div>
<?= $this->endSection()?>