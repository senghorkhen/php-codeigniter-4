<?php namespace App\Controllers;
use App\Models\AdminModel;
class Student extends BaseController
{
	public function index()
	{
		// $data = [

		// 	'name' => 'Romdoul',
		// 	'email'=> 'romdoul@gmail.com',
		// 	'password' => 1234,
		// 	'age'=> 20,
		// 	'province' => 'Takaev'
		// ];
		$student = new AdminModel();
		// $student->insert($data);

		$allStudent['userData'] = $student->findAll();
		return view('students/index', $allStudent);

		return view('students/index');
	}


	public function deleteStudent($id)
	{
		$student = new AdminModel();
		$student->delete($id);
		return redirect()->to('/student');
	}

	public function showDashboard()
	{
		return view('/students/dashboard');
	}

	public function addStudent()
	{
		$student = new AdminModel();
		$student->insert($_POST);
		return redirect()->to('/students');
	}
}
