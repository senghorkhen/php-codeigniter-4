<?= $this->extend('layouts/layout')?>
<?= $this->section('content-blog')?>
<?= $this->include('layouts/navbar') ?>
<h1 class="text-danger">Dashboard</h1>
<?= $this->endSection()?>