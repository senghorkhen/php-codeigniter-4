<?= $this->extend('layouts/layout') ?>

<?= $this->section('content-blog') ?>
<h1 class="text-warning"> User List Informatiom</h1>
<?= $this->endSection(); ?>
