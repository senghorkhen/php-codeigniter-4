<?= $this->extend('layouts/layout') ?>

<?= $this->section('content-blog') ?>
<h1 class="text-danger"> Dashbord Administrator</h1>
<?= $this->endSection(); ?>
