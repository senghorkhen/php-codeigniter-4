<h1>Single Upload File</h1>

<form action="" method="post" enctype="multipart/form-data">
 Photo: <input type="file" name="photo">
 <input type="submit" value="Upload Photo">
</form>